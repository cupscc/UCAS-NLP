import pickle
from model import Seq2SeqTransformer,translate

def load_model():
    with open('model.pkl','rb') as f:
        model=pickle.load(f)
    return model
def load_dicts():
    with open('dicts.pkl','rb') as f:
        dicts=pickle.load(f)
    return dicts
if __name__=="__main__":
    transformer=load_model()
    dicts=load_dicts()
    input_item="这不重要。"
    translate(transformer,dicts,input_item,show=True)
