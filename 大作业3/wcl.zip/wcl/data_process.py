import pandas as pd
import re
import os
from torch.utils.data import Dataset
from sklearn.model_selection import train_test_split
import jieba
from tqdm import trange
import pickle

cn_word2index={'<sos>':0,'<eos>':1,'<pad>':2,'<unk>':3}
en_word2index={'<sos>':0,'<eos>':1,'<pad>':2,'<unk>':3}
cn_count={'<sos>':1e7,'<eos>':1e7-1,'<pad>':1e7-2,'<unk>':1e7-3}
en_count={'<sos>':1e7,'<eos>':1e7-1,'<pad>':1e7-2,'<unk>':1e7-3}
bos=0;eos=1;pad=2;unk=3

class DATASET(Dataset):
    def __init__(self,cn_data,en_data):
        self.cn_data = cn_data
        self.en_data = en_data
    def __len__(self):
        return len(self.cn_data)
    def __getitem__(self,index):
        return self.cn_data[index],self.en_data[index]

class TED_DATASET(Dataset):
    def __init__(self,data_path):
        global cn_word2index,en_word2index
        max_len=30
        max_word_num=10000
        self.data_path=data_path
        with open(data_path+'/TED2020.en-zh_cn.zh_cn','r') as f:
            self.cn_data=f.readlines()
        with open(data_path+'/TED2020.en-zh_cn.en','r') as f:
            self.en_data=f.readlines()
        jieba.lcut('数据集')
        data_map=[2<len(i)<max_len for i in self.cn_data]
        new_cn=[self.cn_data[i] for i in range(len(self.cn_data)) if data_map[i]]
        new_en=[self.en_data[i] for i in range(len(self.en_data)) if data_map[i]]
        self.cn_data=new_cn
        self.en_data=new_en
        for i in trange(len(self.cn_data)):
            cn_sentence=jieba.lcut(self.cn_data[i].strip())
            for word in cn_sentence:
                if word not in cn_word2index:
                    cn_word2index[word]=len(cn_word2index)
                    cn_count[word]=1
                cn_count[word]+=1
            self.cn_data[i]=cn_sentence
        cn_words=list(sorted(cn_word2index.keys(),key=lambda x:cn_count[x],reverse=True))[:max_word_num]
        cn_word2index={word:i for i,word in enumerate(cn_words)}
        for i in range(len(self.cn_data)):
            self.cn_data[i]=[cn_word2index.get(word,unk) for word in self.cn_data[i]]
        for i in trange(len(self.en_data)):
            en_sentence=self.en_data[i].strip().lower()
            en_sentence=en_sentence.replace(' \"','\" ').replace('(','( ')
            for p in ['.',',','!','?',':','\"',')']:
                en_sentence=en_sentence.replace(p,' '+p)
            en_sentence=en_sentence.split(' ')
            for word in en_sentence:
                if word not in en_word2index:
                    en_word2index[word]=len(en_word2index)
                    en_count[word]=1
                en_count[word]+=1
            self.en_data[i]=en_sentence
        en_words=list(sorted(en_word2index.keys(),key=lambda x:en_count[x],reverse=True))[:max_word_num]
        en_word2index={word:i for i,word in enumerate(en_words)}
        for i in range(len(self.en_data)):
            self.en_data[i]=[bos]+[en_word2index.get(word,unk) for word in self.en_data[i]]+[eos]
        cn_train,cn_val,en_train,en_val=train_test_split(self.cn_data,self.en_data,test_size=0.2,random_state=42)
        self.train_data=DATASET(cn_train,en_train)
        self.val_data=DATASET(cn_val,en_val)

def make_dataset():
    global cn_word2index,en_word2index
    data=TED_DATASET('TED数据')
    train_data,val_data=data.train_data,data.val_data
    cn_index2word={v:k for k,v in cn_word2index.items()}
    en_index2word={v:k for k,v in en_word2index.items()}
    with open('data.pkl','wb') as f:
        pickle.dump((train_data,val_data,cn_word2index,cn_index2word,en_word2index,en_index2word),f)
    with open('dicts.pkl','wb') as f:
        pickle.dump((cn_word2index,cn_index2word,en_word2index,en_index2word),f)
    return train_data,val_data,cn_word2index,cn_index2word,en_word2index,en_index2word
