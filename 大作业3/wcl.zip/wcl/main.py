import torch
import pickle
from data_process import make_dataset
from model import Seq2SeqTransformer,create_mask,pad_batch,translate
from data_process import bos,eos,pad,unk
from time import time
from tqdm import tqdm
device=torch.device('cuda')

print("Processing data...")
train_data,val_data,*dicts=make_dataset()
cn_word2index,cn_index2word,en_word2index,en_index2word=dicts
print(f"cn_vocab_size: {len(cn_word2index)}")
print(f"en_vocab_size: {len(en_word2index)}")

batch_size=32
train_loader=torch.utils.data.DataLoader(dataset=train_data,batch_size=batch_size,shuffle=True,collate_fn=pad_batch)
val_loader=torch.utils.data.DataLoader(dataset=val_data,batch_size=batch_size,collate_fn=pad_batch)

SRC_VOCAB_SIZE = len(cn_word2index)
TGT_VOCAB_SIZE = len(en_word2index)
EMB_SIZE = 128
NHEAD = 8
FFN_HID_DIM = 128
BATCH_SIZE = 128
NUM_ENCODER_LAYERS = 3
NUM_DECODER_LAYERS = 3

transformer = Seq2SeqTransformer(NUM_ENCODER_LAYERS, NUM_DECODER_LAYERS, EMB_SIZE,
                                 NHEAD, SRC_VOCAB_SIZE, TGT_VOCAB_SIZE, FFN_HID_DIM)
transformer = transformer.to(device)
loss_fn = torch.nn.CrossEntropyLoss(ignore_index=pad)
optimizer = torch.optim.Adam(transformer.parameters(), lr=0.0001)

def train_epoch(model, optimizer):
    model.train()
    losses = 0
    for src, tgt in tqdm(train_loader):
        src = src.to(device)
        tgt = tgt.to(device)
        tgt_input = tgt[:-1, :]
        src_mask, tgt_mask, src_padding_mask, tgt_padding_mask = create_mask(src, tgt_input)
        logits = model(src, tgt_input, src_mask, tgt_mask,src_padding_mask, tgt_padding_mask, src_padding_mask)
        optimizer.zero_grad()
        tgt_out = tgt[1:, :]
        loss = loss_fn(logits.reshape(-1, logits.shape[-1]), tgt_out.reshape(-1))
        loss.backward()
        optimizer.step()
        losses += loss.item()
    return losses / len(train_loader)

def evaluate(model):
    model.eval()
    losses = 0
    with torch.no_grad():
        for src, tgt in tqdm(val_loader):
            src = src.to(device)
            tgt = tgt.to(device)
            tgt_input = tgt[:-1, :]
            src_mask, tgt_mask, src_padding_mask, tgt_padding_mask = create_mask(src, tgt_input)
            logits = model(src, tgt_input, src_mask, tgt_mask,src_padding_mask, tgt_padding_mask, src_padding_mask)
            tgt_out = tgt[1:, :]
            loss = loss_fn(logits.reshape(-1, logits.shape[-1]), tgt_out.reshape(-1))
            losses += loss.item()
    return losses / len(train_loader)

NUM_EPOCHS = 100
print("Start training...")
best_score = 9999
for epoch in range(1, NUM_EPOCHS+1):
    print(f"Epoch [{epoch}]")
    start_time = time()
    train_loss = train_epoch(transformer, optimizer)
    print("evaluating...")
    val_loss=evaluate(transformer)
    if val_loss<best_score:
        best_score=val_loss
        with open('model.pkl','wb') as f:
            pickle.dump(transformer,f)
    end_time = time()
    print((f"Epoch: {epoch}, Train loss: {train_loss:.3f}, val_loss: {val_loss:.3f},\
     "f"Epoch time = {(end_time - start_time):.3f}s"))
